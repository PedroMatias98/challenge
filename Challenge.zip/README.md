# challenge


## Author 
Pedro Miguel Matias Carvalho

## Mail
pedro.matias.carvalho@gmail.com

## College
Instituto Superior Técnico

## Degree
Computer Science Engineering 3rd year, 2nd semester

## Compile and execute
To compile:
make

To execute:
java -jar Challenge.jar

To clean:
make clean

## Notes
At any moment(except in the bot fetch command, it is possible to end the app by just typing exit).
I considered a system down if at least one of its services was down.

## Requirements
The minimum requirements for the app are all done.
