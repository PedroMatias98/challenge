package domain;

public class Github extends Platform {
    public Github(String id, String name, String statusUrl, String statusApiUrl){
        super(id,name,statusUrl,statusApiUrl);
    }
}