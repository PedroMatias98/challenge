package domain;

public class Bitbucket extends Platform {
    public Bitbucket(String id, String name, String statusUrl, String statusApiUrl){
        super(id,name,statusUrl,statusApiUrl);
    }
}